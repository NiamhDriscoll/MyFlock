MyFlock 0.61

Thursday, November 14, 2024
Changed all text documents from .txt to .md
Friday, November 15, 2024
Changed more text documents to Markdown
Added CHANGELOG.md to GitHub
Added MyFlock.cmd
Bug fixes

MyFlock 0.62

Friday, November 15, 2024
Updated app.py
Bug fixes