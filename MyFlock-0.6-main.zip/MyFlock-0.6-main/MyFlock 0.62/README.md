MyFlock version 0.62
Updated November 9, 2024
This is a prerelease version of MyFlock.
About MyFlock: MyFlock is a free website for helping chicken owners manage their chickens.

MyFlock is develeped by Niamh Industries and these people:
Niamh M. Olson
MyFlock uses font(s) from 1001fonts.com. For more, read 1001fonts-chopin-script-eula.txt or OFL.txt 


