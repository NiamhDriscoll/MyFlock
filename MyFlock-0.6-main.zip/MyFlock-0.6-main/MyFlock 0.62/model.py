class User:

    def __init__(self,email, password):
        self.username = self
        self.password = self
        pass 
    
    user1 = user()
    user1.admin = Yes
    